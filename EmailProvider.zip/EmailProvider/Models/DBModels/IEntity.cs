﻿//Includes

namespace EmailServiceIntermediate.Models
{
    //------------------------------------------------------
    //	IEntity
    //------------------------------------------------------

    /// <summary> Базов интерфейс за всички модели </summary>
    public interface IEntity
    {
        int Id { get; set; }
    }
}
